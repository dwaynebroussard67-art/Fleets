# FLEET

A gig-worker collective platform. Not a competitor to Uber/DoorDash/Lyft — infrastructure for the workers those platforms depend on.

## The problem

Gig drivers face three traps:

1. **Reputation trap** — ratings are owned by the platform and vanish on deactivation
2. **Vehicle trap** — can't earn without a car, can't afford a car without earning
3. **Isolation trap** — contractor status means no collective voice, no coordination, no one saying "you did good today"

## What FLEET is

A driver-owned platform built around a portable reputation score, a path to vehicle ownership, and a place for drivers to be seen — by each other and by the app itself.

## MVP scope (Phase 1 — build this first)

Per the staged plan, cut everything below for v1 and ship only:

- **Portable reputation** — the Fleet Score, driver-owned, not platform-owned
- **Daily recognition** — driver logs a delivery/shift (time, date, duration); the app generates a short, specific, non-repeating acknowledgment grounded in what they logged. Not generic praise — meaning. ("You got six people their food who had no way to get it themselves.")
- **Basic driver profile + auth**

### Explicitly OUT of MVP (add later, in order)
- Phase 2: local-business hiring marketplace (Stripe Connect, 8% fee)
- Phase 3: benefits pool + partnerships
- Cut entirely from near-term roadmap: blockchain/IPFS/Polygon anchoring, Pinecone, vehicle financing program, chapter/captain governance, collective-action tooling

See `docs/FLEET_SPEC.md` for the full original concept — everything above is what's in scope *now*; the rest is documented so nobody re-derives it from scratch or builds toward it by accident.

## Stack

- **Web**: Next.js (App Router)
- **Mobile** (later, not MVP): React Native / Expo
- **API**: Node/Express or Fastify
- **DB**: Postgres (Supabase)
- **Auth**: Supabase Auth
- Redis, PostGIS, Socket.io, Stripe Connect, Mapbox — all Phase 2+, not needed for MVP

## Known issues to avoid (from prior refactor pass)

- No unparameterized SQL — use parameterized queries / an ORM, always
- No unsafe-inline in CSP
- Watch template literal construction for injection risk

## Status

Repo initialized. No app code written yet. This commit is scaffold only.
