export default function Home() {
  return (
    <main>
      <h1>FLEET</h1>
      <p>Driver-owned reputation and recognition. Build starts here — see /docs/FLEET_SPEC.md.</p>
    </main>
  );
}
